<template>
  <div>
    <p>{{ person.name }}</p>
    <input type="text" name="" value=""><br>
    <br><p>{{ person.mdp }}</p>
    <input type="password" name="" value=""><br>
    <button type="button-on-click" name="Annuler">Annuler</button>
    <button type="button-on-click" name="Entrer">Entrer</button>
  </div>
</template>

<script>
export default {
  data(){
    return {
      person: {
      name: 'Username',
      mdp: 'Password'
      }
    }
  }
}
</script>

<style>
</style>
