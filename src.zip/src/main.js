import Vue from 'vue';

import './plugins';

import App from './app/app.vue';
import Jeux from './app/app-jeux.vue'
import Friends from './app/app-friends.vue'



import './main.scss';

Vue.config.productionTip = false
/* eslint-disable no-new */

const routes = {
  '/login': App,
  '/jeux': Jeux,
  '/friends': Friends
}

new Vue({
  render: h => h(App)
}).$mount('#app');


new Vue({
  render: j => j(Jeux)
}).$mount('#jeux');

new Vue({
  render: f => f(Friends)
}).$mount('#friends');
