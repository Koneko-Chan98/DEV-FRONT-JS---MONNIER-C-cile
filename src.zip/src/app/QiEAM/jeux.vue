<template>
  <div>
    <p>{{ jeux.collection }}</p>
    <br><p>{{ jeux.buy }}</p>


  </div>
</template>

<script>
export default {
  data(){
    return {
      jeux: {
        collection: 'hello',
        buy: 'World'

      }
    }
  }
}
</script>

<style>
</style>
