<template>
  <div id="friends">
    <img src="../assets/QiEAM.png">
    <Friends/>
  </div>

</template>

<script>
import Friends from '../app/QiEAM/friends'

export default {
  name: 'friends',
  components: {
    Friends
  }
}
</script>

<style>
#fiends {
  front-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 100xp;
}
#img {
  text-align: top;
}
</style>
