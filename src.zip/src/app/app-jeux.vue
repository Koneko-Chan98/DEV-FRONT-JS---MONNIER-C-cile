<template>
  <div id="jeux">
    <img src="../assets/QiEAM.png">
    <Jeux/>
  </div>

</template>

<script>
import Jeux from '../app/QiEAM/jeux'

export default {
  name: 'jeux',
  components: {
    Jeux
  }
}
</script>

<style>
#jeux {
  front-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 100xp;
}
#img {
  text-align: top;
}
</style>
