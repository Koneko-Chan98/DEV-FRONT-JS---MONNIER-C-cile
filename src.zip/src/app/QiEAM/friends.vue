<template>
  <div>
    <input type="search" id="site-search" name="q"><br>
    <p>{{ friends.amis }}</p>


  </div>
</template>
Basic Friends :
  var config = {
  method: 'get',
  url: 'https://qieam-api.herokuapp.com/api/friends',
  headers: {
  'Authorization': 'Basic 5b3ac6ae920020c868108033c04d9fbb'
  }
},
<script>


export default {
  data(){
    return {
      friends: {
        amis: []
      }
    }
  }
}

</script>

<style>
</style>
mounted() {
  axios.get("https://qieam-api.herokuapp.com/api/friends")
  User => 5b3ac6ae920020c868108033c04d9fbb
  Password => 5b3ac6ae920020c868108033c04d9fb
  .then(response => {this.results = response.data.results})
}
this.responseAvailable = false;
fetch("https://qieam-api.herokuapp.com/api/friends", {
    "method": "GET",
    "headers": {
        "x-rapidapi-host": "5b3ac6ae920020c868108033c04d9fbb",
        "x-rapidapi-key": 5b3ac6ae920020c868108033c04d9fbb
    }
})
.then(response => {
    if(response.ok){
        return response.json()
    } else{
        alert("Server returned " + response.status + " : " + response.statusText);
    }
})
.then(response => {
    this.result = response.body;
    this.responseAvailable = true;
})
.catch(err => {
    console.log(err);
});
