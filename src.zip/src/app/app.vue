<template>
  <div id="app">
    <img src="../assets/QiEAM.png">
    <Login/>
  </div>

</template>

<script>
import Login from '../app/QiEAM/login'


export default {
  name: 'app',
  components: {
    Login
  }
}

</script>

<style>
#app {
  front-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 100xp;
}

</style>
